package com.ecommerce.application.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Cart")
public class Cart {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "cart_id")
	    private int cart_id;
	 
	    @Column(name = "quantity")
	    private int quantity;
	    
	    @Column(name = "customer_id")
	    private int customer_id;
	    
	    @Column(name = "product_id")
	    private int product_id;
	    
	    
	    
		public Cart() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getquantity() {
			return quantity ;
		}
		public void setquantity(int quantity) {
			this.quantity = quantity;
		}
		public int getcustomer_id() {
			return customer_id;
		}
		public void setcustomer_id(int customer_id) {
			this.customer_id = customer_id;
		}
		
		public int getproduct_id() {
			return product_id;
		}
		public void setproduct_id(int product_id) {
			this.product_id = product_id;
		}
		
		public long getcart_id() {
			return cart_id;
		}
		
	    

}
