package com.ecommerce.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ecommerce.application.modal.Cart;
import com.ecommerce.application.modal.Category;
import com.ecommerce.application.repo.CategoryRepo;


public class CategoryController {
	@Autowired
	private CategoryRepo categoryRepo;
	
	 @PostMapping("/categoryRepo")
	    public Category createCategory(@RequestBody Category reg) {
	        return categoryRepo.save(reg);
	    
	 }
	 @GetMapping("/categorylogin")
	    public List<Cart> checkUser() {
	        return categoryRepo.findAll();
	 }
	 }
	


