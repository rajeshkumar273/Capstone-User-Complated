package com.ecommerce.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.ecommerce.application.modal.Admin;
import com.ecommerce.application.repo.AdminRepo;


public class AdminController {
	@Autowired
	private AdminRepo adminRepo;
	
	 @PostMapping("/adminRepo")
	    public Admin createAdmin(@RequestBody Admin reg) {
	        return adminRepo.save(reg);
	    }
	 @GetMapping("/adminlogin")
	    public List < Admin > checkUser() {
	        return adminRepo.findAll();
	 }
}

/*
 * @PostMapping("/admin_signin")
	public String login(@ModelAttribute(name = "loginForm") Admin admin, Model a) {
		String email = admin.getEmail();
		String pass = admin.getPassword();
		
		//System.out.println("from form :" + email + "\n" + pass);
		
		Admin loginUser = adminRepo.findByEmail(email);
		
		//System.out.println("from database: " + loginUser.getEmail() + "\n" + loginUser.getPassword());
		
		if (email.equals(loginUser.getEmail()) && pass.equals(loginUser.getPassword())) {
			a.addAttribute("uname", email);
			a.addAttribute("pass", pass);
			return "categories";
		}
		a.addAttribute("error", "Incorrect Username & Password");
		return "signin";

	}
 */

