package com.ecommerce.application.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ecommerce.application.modal.Admin;




public interface AdminRepo extends JpaRepository<Admin, Integer>{

	@Query("SELECT a FROM User a WHERE a.email = ?1")
	public Admin findByEmail(String ad_email);
	
	
}